﻿namespace ConsoleForum.Contracts
{
    public interface IAnswer : IPost
    {
    }
}
